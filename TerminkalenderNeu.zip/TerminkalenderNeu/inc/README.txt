Ordner inc

functions.inc.php --> wichtige Funktionen f�rs Login. Beispiel: Checkuser f�r Session und Sicherheit 
password.inc.php --> hier wird das Passwort gehasht
config.inc.php --> Einstellung f�r die Datenbankverbindung (Login)
config.inc.2.php --> Einstellung f�r die Datenbankverbidnung (Kundennummern)
db.php --> Fehlermeldung falls keine Verbindung zu Kundennummern DB
index.php --> Hier kann der Auftraggeber die Kunden eintragen. Zufallszahlgenerator und bearbeiten/l�schen sind ebenfalls dabei.
