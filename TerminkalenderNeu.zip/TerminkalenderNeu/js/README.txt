Ordner js

Hier sind JavaScript-Frameworks von Bootstrap (bootstrap.js, bootstrap.min.js)
Superagent.js und theme-chooser.js sind default js Templates 