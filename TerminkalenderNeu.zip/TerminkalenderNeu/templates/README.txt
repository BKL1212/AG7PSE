Ordner templates 

Hier sind die Templates f�r den Footer (ganz unten), Header (ganz oben), und Error

Es ist sozusagen vordefiniert wie der Header aussehen soll: In unserem Fall mit dem Login und links die Beschriftung "Ines Sch�nbrunn Terminkalender"
Im footer steht nichts drin , aber kann einfach durch html hinzugef�gt werden.