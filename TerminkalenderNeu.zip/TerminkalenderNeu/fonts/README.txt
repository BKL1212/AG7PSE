Ordner fonts

Hier sind Bibliotheken f�r einfache Glyphicons (sowas wie Emoticons)