<?php

//für Zeitzone
echo json_encode(DateTimeZone::listIdentifiers());