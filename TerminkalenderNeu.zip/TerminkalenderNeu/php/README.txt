Ordner php
terminkalender.php -->
Momentan ist die Funktion f�r das Versenden einer e-Mail bei Index.php (unter Termin anfragen) extern gel�st, da man trotz lokalem Server �ber diese externe L�sung eine Mail �ber den Server des externen Dienstleisters verschicken kann.
F�r eine sehr gute Note haben wir auch eine PHP Funktion f�r das Versenden einer e-Mail geschrieben. Wenn man die Dateien auf einen Webserver hochl�dt ist ein Mailserver gleich mitintegriert, sodass die Funktionen ausgef�hrt werden k�nnen. Dies Funktioniert unter emailverschickenWEBSERVER.html.


get-time-zones.php --> identifiziert die Zeitzone
utils.php --> Funktion f�r die Zeitzonen Einstellung