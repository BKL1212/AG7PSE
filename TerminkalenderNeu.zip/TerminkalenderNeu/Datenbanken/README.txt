Ordner Datenbanken

Hier sind die datenbanken f�r fehlerfreien Test am besten einfach importieren �ber phpmyadmin
login.sql --> in PhpmyAdmin importieren f�r login (erzeugt die DB login mit Tabelle users und securitytoken )
kundennummern.sql --> in PhpmyAdmin importieren f�r Kundennummern ( erzeugt die DB kundennummern mit Tabelle kunden)



