Ordner locales

Hier kann man einstellen welche Sprache man m�chte in dem man die gewollte locale in den fullcalendar.js eintr�gt.
